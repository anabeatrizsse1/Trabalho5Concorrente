import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Dafne extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 5;
  private double eixoX = 246;
  private double eixoY = 501;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Dafne(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarSlider(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverDafne();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public int getVelocidade() {
    return velocidade;
  }

  public void setVelocidade(int velocidade) {
    this.velocidade = velocidade;
  }

  public void MoverDafne() throws InterruptedException {
    controle.semaforoFr2_D1.acquire();
    controle.semaforoSl_D.acquire();
    // DescerEixoY(502);
    controle.semaforoF2_D1.acquire();
    DescerEixoY(551);
    MoverEixoXEsq(18);
    SubirEixoY(406);
    controle.semaforoVr3_D2.acquire();

    SubirEixoY(335);
    MoverEixoXDir(80);
    controle.semaforoSl_D.release();

    controle.semaforoFr2_D1.release();

    controle.semaforoF2_D1.release();
    controle.semaforoF3_D2.acquire();

    MoverEixoXDir(131);
    SubirEixoY(280);
    controle.semaforoVr3_D2.release();
    controle.semaforoVr4_D1.acquire();

    controle.semaforoV_D.acquire();

    controle.semaforoF3_D2.release();
    SubirEixoY(237);
    MoverEixoXDir(180);
    controle.semaforoF6_Vr7.acquire();

    MoverEixoXDir(245);
    SubirEixoY(177);
    controle.semaforoV_D.release();

    controle.semaforoF6_Vr7.release();
    controle.semaforoF1_D4.acquire();

    SubirEixoY(127);
    MoverEixoXDir(311);
    controle.semaforoVr4_D1.release();
    controle.semaforoF2_Vr1.acquire();

    controle.semaforoP1_D1.acquire();

    MoverEixoXDir(371);

    SubirEixoY(72);
    controle.semaforoFr1_D2.acquire();

    SubirEixoY(16);
    MoverEixoXDir(428);
    controle.semaforoF2_Vr1.release();

    MoverEixoXDir(595);
    DescerEixoY(180);
    controle.semaforoVr1_D4.acquire();

    DescerEixoY(224);
    MoverEixoXEsq(542);
    controle.semaforoP1_D1.release();

    controle.semaforoF1_D4.release();
    MoverEixoXEsq(484);
    DescerEixoY(280);
    controle.semaforoVr1_D4.release();
    controle.semaforoVr2_D3.acquire();

    controle.semaforoFr1_D2.release();
    controle.semaforoF8_Vr4.acquire();

    DescerEixoY(335);
    MoverEixoXEsq(428);
    controle.semaforoP2_V2.acquire();

    MoverEixoXEsq(371);
    DescerEixoY(400);
    controle.semaforoFr2_D1.acquire();

    controle.semaforoF8_Vr4.release();

    DescerEixoY(456);
    MoverEixoXEsq(313);
    controle.semaforoP2_V2.release();

    MoverEixoXEsq(254);

    DescerEixoY(502);
    // MoverEixoXEsq(325);
    controle.semaforoFr2_D1.release();
    controle.semaforoVr2_D3.release();

  }

  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarSlider(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }

}
