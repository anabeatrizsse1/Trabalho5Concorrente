import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Scoob extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 5;
  private double eixoX = 12;
  private double eixoY = 238;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Scoob(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarSlider(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverScoob();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverScoob() throws InterruptedException {
    controle.semaforoV_S.acquire();
    controle.semaforoS_Sl.acquire();
    controle.semaforoS1_D1.acquire();

    MoverEixoXDir(178);
    controle.semaforoF3_S1.acquire();
    MoverEixoXDir(314);
    controle.semaforoS2_P2.acquire();
    controle.semaforoFr4_S1.acquire();
    MoverEixoXDir(328);
    controle.semaforoS1_D1.release();
    controle.semaforoS4_D4.acquire();

    MoverEixoXDir(438);
    controle.semaforoS2_P2.release();
    controle.semaforoS_Sl.release();

    controle.semaforoF3_S1.release();
    MoverEixoXDir(532);
    controle.semaforoF5_S2.acquire();
    MoverEixoXDir(599);
    DescerEixoY(292);
    controle.semaforoV_S.release();

    controle.semaforoFr4_S1.release();
    DescerEixoY(407);
    controle.semaforoS4_D4.release();

    controle.semaforoFr3_S2.acquire();

    DescerEixoY(464);

    MoverEixoXEsq(573);
    controle.semaforoF5_S2.release();

    controle.semaforoF4_S3.acquire();
    MoverEixoXEsq(427);
    controle.semaforoS2_Vr2.acquire();
    controle.semaforoS2_D2.acquire();

    controle.semaforoS1_P1.acquire();

    controle.semaforoFr2_S3.acquire();

    controle.semaforoFr3_S2.release();

    controle.semaforoF4_S3.release();
    MoverEixoXEsq(307);
    controle.semaforoS2_Vr2.release();
    controle.semaforoS3_Vr3.acquire();

    controle.semaforoS2_D2.release();
    controle.semaforoS3_D3.acquire();

    controle.semaforoS1_P1.release();

    MoverEixoXEsq(192);
    controle.semaforoS3_Vr3.release();

    controle.semaforoFr2_S3.release();
    controle.semaforoF2_S4.acquire();
    controle.semaforoS3_D3.release();

    MoverEixoXEsq(90);
    controle.semaforoS_Sl.acquire();

    controle.semaforoF2_S4.release();
    controle.semaforoF1_S5.acquire();
    MoverEixoXEsq(12);
    controle.semaforoS1_D1.acquire();

    SubirEixoY(238);
    MoverEixoXDir(177);
    controle.semaforoF1_S5.release();
    controle.semaforoS_Sl.release();
    controle.semaforoS1_D1.release();

  }

  /*
   * ***************************************************************
   * Metodo: moveDireitaX
   * Funcao: move a personagem em sua vassoura para a direita
   * Parametros: int ondeVai
   * Retorno: void
   */
  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarSlider(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }
}
