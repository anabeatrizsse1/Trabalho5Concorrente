import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Velma extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 5;
  private double eixoX = 438;
  private double eixoY = 22;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Velma(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarValor(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverVelma();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverVelma() throws InterruptedException {
    // MoverEixoXEsq(437);
    controle.semaforoFr2_Vr1.acquire();
    // controle.semaforoFr1_V1.acquire();
    MoverEixoXEsq(327);
    controle.semaforoF4_V3.acquire();
    MoverEixoXEsq(199);
    controle.semaforoFr2_Vr1.release();

    MoverEixoXEsq(18);
    // controle.semaforoF4_Fr2.release();
    // controle.semaforoF4_V3.acquire();
    DescerEixoY(180);
    controle.semaforoV_Sl.acquire();
    controle.semaforoV1_Vr1.acquire();

    controle.semaforoV_S.acquire();
    DescerEixoY(232);

    MoverEixoXDir(81);
    controle.semaforoV_D.acquire();

    controle.semaforoF4_V3.release();

    MoverEixoXDir(205);
    controle.semaforoF5_V4.acquire();
    MoverEixoXDir(327);
    // controle.semaforoFr1_V1.release();

    controle.semaforoV_D.release();

    controle.semaforoV2_Vr2.acquire();

    controle.semaforoV1_Vr1.release();

    controle.semaforoV_P.acquire();

    MoverEixoXDir(438);
    controle.semaforoFr1_V1.acquire();

    controle.semaforoFr1_D2.acquire();
    controle.semaforoV_Sl.release();

    controle.semaforoF5_V4.release();
    controle.semaforoV_P.release();

    MoverEixoXDir(560);
    controle.semaforoV_P.acquire();

    MoverEixoXDir(616);
    SubirEixoY(180);
    controle.semaforoV_S.release();
    controle.semaforoV2_Vr2.release();

    SubirEixoY(22);
    MoverEixoXEsq(342);
    controle.semaforoFr1_V1.release();

    controle.semaforoV_P.release();
    controle.semaforoFr1_D2.release();

    // MoverEixoXEsq(327);
    // controle.semaforoF4_V3.acquire();
    // MoverEixoXEsq(496);
    // controle.semaforoF2_V1.acquire();

    // controle.semaforoF2_V1.release();

  }

  // public void Mover;
  /*
   * ***************************************************************
   * Metodo: moveDireitaX
   * Funcao: move a personagem em sua vassoura para a direita
   * Parametros: int ondeVai
   * Retorno: void
   */
  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarValor(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }
}
