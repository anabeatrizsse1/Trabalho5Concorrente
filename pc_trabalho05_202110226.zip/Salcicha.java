import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Salcicha extends Thread {
  TelaController controle = new TelaController();
  Scoob scoob;
  private int velocidade = 5;
  private double eixoX = 373;
  private double eixoY = 267;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Salcicha(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarSlider(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverSalcicha();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverSalcicha() throws InterruptedException {
    controle.semaforoV_Sl.acquire();
    controle.semaforoS_Sl.acquire();
    controle.semaforoV_D.acquire();
    // SubirEixoY(237);
    // MoverEixoXEsq(328);
    controle.semaforoP2_Sl2.acquire();

    MoverEixoXEsq(70);
    controle.semaforoV_D.release();

    controle.semaforoF1_Sl2.acquire();
    controle.semaforoFr1_Sl1.acquire();

    MoverEixoXEsq(18);
    DescerEixoY(292);
    controle.semaforoSl_D.acquire();
    controle.semaforoV_Sl.release();
    DescerEixoY(406);
    controle.semaforoP2_Sl2.release();

    DescerEixoY(527);
    controle.semaforoS_Sl.release();
    controle.semaforoS_Sl.release();

    DescerEixoY(551);
    controle.semaforoF2_Sl3.acquire();
    MoverEixoXDir(69);
    controle.semaforoF1_Sl2.release();
    MoverEixoXDir(187);
    controle.semaforoP3_Sl3.acquire();

    MoverEixoXDir(205);
    controle.semaforoF2_Sl3.release();
    MoverEixoXDir(330);
    controle.semaforoSl_D.release();

    controle.semaforoFr1_Sl1.release();
    controle.semaforoFr2_Sl2.acquire();
    controle.semaforoP_Sl.acquire();

    MoverEixoXDir(376);
    SubirEixoY(527);
    controle.semaforoP2_V2.acquire();

    controle.semaforoS1_P1.acquire();

    SubirEixoY(406);
    controle.semaforoFr2_Sl2.release();
    controle.semaforoS1_P1.release();

    controle.semaforoF3_Sl1.acquire();
    controle.semaforoF4_P3.acquire();
    SubirEixoY(292);
    controle.semaforoP2_V2.release();

    controle.semaforoP3_Sl3.release();
    controle.semaforoP1_Sl1.acquire();

    controle.semaforoV_Sl.acquire();
    controle.semaforoS_Sl.acquire();

    SubirEixoY(267);
    MoverEixoXEsq(303);
    controle.semaforoP2_Sl2.acquire();

    controle.semaforoP_Sl.release();
    controle.semaforoP1_Sl1.release();

    controle.semaforoF4_P3.release();

    MoverEixoXEsq(187);
    controle.semaforoF3_Sl1.release();
    MoverEixoXEsq(71);
    controle.semaforoP2_Sl2.release();

    // controle.semaforoS_Sl.release();

    controle.semaforoV_Sl.release();

  }

  // public void Mover;
  /*
   * ***************************************************************
   * Metodo: moveDireitaX
   * Funcao: move a personagem em sua vassoura para a direita
   * Parametros: int ondeVai
   * Retorno: void
   */
  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });

      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });

      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });

      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });

      eixoY++;

    }

  }

  public void modificarSlider(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }

}
