import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Fred extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 5;
  private double eixoX = 627;
  private double eixoY = 19;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Fred(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarValor(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverFred();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverFred() throws InterruptedException {

    // controle.semaforoFr1_D2.acquire();
    // MoverEixoXEsq(627);
    // controle.semaforoFr1_V1.acquire();

    MoverEixoXEsq(451);
    controle.semaforoF2_Fr7.acquire();
    controle.semaforoFr1_P3.acquire();

    controle.semaforoFr2_Vr1.acquire();
    MoverEixoXEsq(342);
    // controle.semaforoFr1_D2.release();

    controle.semaforoF2_Fr7.release();
    controle.semaforoFr1_P3.release();

    // MoverEixoXEsq(276);
    controle.semaforoF4_Fr2.acquire();
    MoverEixoXEsq(217);
    controle.semaforoFr2_Vr1.release();

    MoverEixoXEsq(36);
    // controle.semaforoF5_Fr3.acquire();
    DescerEixoY(73);
    // controle.semaforoF4_Fr2.release();
    DescerEixoY(180);
    controle.semaforoF4_Vr6.acquire();

    controle.semaforoFr1_Sl1.acquire();
    controle.semaforoF1_S5.acquire();
    DescerEixoY(280);
    // controle.semaforoFr1_V1.release();

    controle.semaforoFr2_D1.acquire();

    DescerEixoY(408);
    controle.semaforoF4_Vr6.release();

    // controle.semaforoFr2_V2.release();

    DescerEixoY(514);
    controle.semaforoF1_S5.release();

    DescerEixoY(553);
    // controle.semaforoF6_Fr4.acquire();
    MoverEixoXDir(96);
    // controle.semaforoF5_Fr3.release();
    MoverEixoXDir(218);
    controle.semaforoFr3_Vr4.acquire();

    controle.semaforoF4_Fr2.release();
    MoverEixoXDir(279);
    SubirEixoY(522);
    controle.semaforoFr1_Sl1.release();
    controle.semaforoFr2_S3.acquire();

    SubirEixoY(458);
    MoverEixoXDir(342);
    controle.semaforoFr3_Vr4.release();
    controle.semaforoFr4_Vr3.acquire();

    controle.semaforoFr2_P1.acquire();
    controle.semaforoFr2_Sl2.acquire();

    MoverEixoXDir(396);
    DescerEixoY(522);
    controle.semaforoFr2_D1.release();

    controle.semaforoFr2_S3.release();

    DescerEixoY(553);
    MoverEixoXDir(454);
    controle.semaforoFr4_Vr3.release();

    controle.semaforoFr2_Sl2.release();

    MoverEixoXDir(544);
    controle.semaforoF8_Fr6.acquire();
    MoverEixoXDir(633);
    controle.semaforoF8_Fr6.release();
    controle.semaforoF1_Fr6.acquire();
    SubirEixoY(522);
    controle.semaforoFr3_S2.acquire();

    SubirEixoY(458);
    controle.semaforoF1_Fr6.release();
    MoverEixoXEsq(552);
    controle.semaforoFr2_P1.release();

    controle.semaforoF7_Fr5.acquire();

    MoverEixoXEsq(513);
    SubirEixoY(395);
    controle.semaforoF8_Vr4.acquire();

    controle.semaforoFr3_S2.release();

    SubirEixoY(344);
    MoverEixoXEsq(454);
    // controle.semaforoF4_P3.acquire();
    // controle.semaforoFr3_Sl3.acquire();

    MoverEixoXEsq(403);
    SubirEixoY(286);
    controle.semaforoFr1_V1.acquire();

    controle.semaforoF8_Vr4.release();

    // controle.semaforoFr2_V2.acquire();

    controle.semaforoFr4_S1.acquire();

    SubirEixoY(232);
    MoverEixoXDir(454);
    controle.semaforoFr1_D2.acquire();

    MoverEixoXDir(503);
    // controle.semaforoF4_P3.release();
    // controle.semaforoFr3_Sl3.release();

    MoverEixoXDir(513);
    controle.semaforoF7_Fr5.release();
    MoverEixoXDir(570);
    // controle.semaforoFr2_P1.acquire();
    controle.semaforoF2_Fr7.acquire();

    MoverEixoXDir(629);
    SubirEixoY(179);

    // controle.semaforoF2_Fr7.acquire();

    controle.semaforoFr4_S1.release();

    SubirEixoY(19);
    // MoverEixoXEsq(453);
    // controle.semaforoFr1_P3.release();
    controle.semaforoF2_Fr7.release();
    MoverEixoXEsq(451);
    controle.semaforoFr1_V1.release();

    controle.semaforoFr1_D2.release();

    // controle.semaforoF2_Fr7.release();
    // controle.semaforoFr1_P3.acquire();

  }

  // public void Mover;
  /*
   * ***************************************************************
   * Metodo: moveDireitaX
   * Funcao: move a personagem em sua vassoura para a direita
   * Parametros: int ondeVai
   * Retorno: void
   */
  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarValor(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }

}
