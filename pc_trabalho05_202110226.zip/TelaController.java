import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.Semaphore;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class TelaController implements Initializable {

  @FXML
  private ImageView dafne, dracula, fantasma, fred, palhaco, salsicha, scoob, velma;

  @FXML
  private Slider slider1, slider2, slider3, slider4, slider5, slider6, slider7, slider8;

  @FXML
  public CheckBox checkBOX;
  @FXML
  public CheckBox music;// checkbox para a musica
  @FXML
  private ImageView botaomusic;

  @FXML
  private Button D;

  @FXML
  private Button Dc;

  @FXML
  private Button F;

  @FXML
  private Button Ft;

  @FXML
  private Button P;

  @FXML
  private Button S;

  @FXML
  private Button V;

  @FXML
  private Button Sc;

  private Transito fant;
  private Fred percurso3;
  private Scoob percurso9;
  private Velma percurso7;
  private Palhaco percurso14;
  private Salcicha percurso17;
  private Vampiro percurso19;
  private Dafne percurso24;

  @FXML
  void PausarDafne(ActionEvent event) {
    if (D.getText().equals("| |")) {
      percurso24.suspend();
      D.setText("despausar");
    } else {
      D.setText("| |");
      percurso24.resume();
    }

  }

  @FXML
  void PausarDracula(ActionEvent event) {
    if (Dc.getText().equals("| |")) {
      percurso19.suspend();
      Dc.setText("despausar");
    } else {
      Dc.setText("| |");
      percurso19.resume();
    }

  }

  @FXML
  void PausarFantasma(ActionEvent event) {
    if (Ft.getText().equals("| |")) {
      fant.suspend();
      Ft.setText("despausar");
    } else {
      Ft.setText("| |");
      fant.resume();
    }
  }

  @FXML
  void PausarFred(ActionEvent event) {
    if (F.getText().equals("| |")) {
      percurso3.suspend();
      F.setText("despausar");
    } else {
      F.setText("| |");
      percurso3.resume();
    }

  }

  @FXML
  void PausarPalhaco(ActionEvent event) {
    if (P.getText().equals("| |")) {
      percurso14.suspend();
      P.setText("despausar");
    } else {
      P.setText("| |");
      percurso14.resume();
    }

  }

  @FXML
  void PausarSalsicha(ActionEvent event) {
    if (S.getText().equals("| |")) {
      percurso17.suspend();
      S.setText("despausar");
    } else {
      S.setText("| |");
      percurso17.resume();
    }

  }

  @FXML
  void PausarScoob(ActionEvent event) {
    if (Sc.getText().equals("| |")) {
      percurso9.suspend();
      Sc.setText("despausar");
    } else {
      Sc.setText("| |");
      percurso9.resume();
    }

  }

  @FXML
  void PausarVelma(ActionEvent event) {
    if (V.getText().equals("| |")) {
      percurso7.suspend();
      V.setText("despausar");
    } else {
      V.setText("| |");
      percurso7.resume();
    }

  }

  @FXML
  public void reiniciar() {
    percurso9.stop();
    percurso7.stop();
    percurso3.stop();
    percurso24.stop();
    percurso19.stop();
    percurso17.stop();
    percurso14.stop();
    fant.stop();

    percurso24.recomecoThread();
    percurso14.recomecoThread();
    percurso17.recomecoThread();
    percurso19.recomecoThread();
    percurso3.recomecoThread();
    percurso7.recomecoThread();
    percurso9.recomecoThread();
    fant.recomecoThread();
    ReiniciarCarros();
    start();
  }

  @FXML
  public void start() {
    CaixaDeMusica.play("musica.wav"); // Executa a música
    music.setSelected(true); // Define a seleção padrão do checkbox "Música"
    fant = new Transito(this, fantasma, slider7);
    fant.start();
    percurso3 = new Fred(this, fred, slider3);
    percurso3.start();
    percurso9 = new Scoob(this, scoob, slider4);
    percurso9.start();
    percurso7 = new Velma(this, velma, slider5);
    percurso7.start();
    percurso14 = new Palhaco(this, palhaco, slider8);
    percurso14.start();
    percurso17 = new Salcicha(this, salsicha, slider1);
    percurso17.start();
    percurso19 = new Vampiro(this, dracula, slider6);
    percurso19.start();
    percurso24 = new Dafne(this, dafne, slider2);
    percurso24.start();
  }

  public Semaphore semaforoF1_Fr6 = new Semaphore(1);
  public Semaphore semaforoF2_Fr7 = new Semaphore(1);
  public Semaphore semaforoF3_Fr1 = new Semaphore(1);
  public Semaphore semaforoF4_Fr2 = new Semaphore(1);
  public Semaphore semaforoF5_Fr3 = new Semaphore(1);
  public Semaphore semaforoF6_Fr4 = new Semaphore(1);
  public Semaphore semaforoF7_Fr5 = new Semaphore(1);
  public Semaphore semaforoF8_Fr6 = new Semaphore(1);
  public Semaphore semaforoF1_S5 = new Semaphore(1);
  public Semaphore semaforoF2_S4 = new Semaphore(1);
  public Semaphore semaforoF3_S1 = new Semaphore(1);
  public Semaphore semaforoF4_S3 = new Semaphore(1);
  public Semaphore semaforoF5_S2 = new Semaphore(1);
  public Semaphore semaforoF1_V5 = new Semaphore(1);
  public Semaphore semaforoF2_V1 = new Semaphore(1);
  public Semaphore semaforoF3_V2 = new Semaphore(1);
  public Semaphore semaforoF4_V3 = new Semaphore(1);
  public Semaphore semaforoF5_V4 = new Semaphore(1);
  
  // public Semaphore semaforoF6_V5= new Semaphore(1)
  public Semaphore semaforoF1_P5 = new Semaphore(1);
  public Semaphore semaforoF2_P1 = new Semaphore(1);
  public Semaphore semaforoF3_P2 = new Semaphore(1);
  public Semaphore semaforoF4_P3 = new Semaphore(1);
  public Semaphore semaforoF5_P4 = new Semaphore(1);
  public Semaphore semaforoF1_Sl2 = new Semaphore(1);
  public Semaphore semaforoF2_Sl3 = new Semaphore(1);
  public Semaphore semaforoF3_Sl1 = new Semaphore(1);
  public Semaphore semaforoF1_Vr3 = new Semaphore(1);
  public Semaphore semaforoF2_Vr1 = new Semaphore(1);
  public Semaphore semaforoF3_Vr9 = new Semaphore(1);
  public Semaphore semaforoF4_Vr6 = new Semaphore(1);
  public Semaphore semaforoF5_Vr5 = new Semaphore(1);
  public Semaphore semaforoF6_Vr7 = new Semaphore(1);
  public Semaphore semaforoF7_Vr2 = new Semaphore(1);
  public Semaphore semaforoF8_Vr4 = new Semaphore(1);
  public Semaphore semaforoF1_D4 = new Semaphore(1);
  public Semaphore semaforoF2_D1 = new Semaphore(1);
  public Semaphore semaforoF3_D2 = new Semaphore(1);
  // public Semaphore semaforoF4_D3= new Semaphore(1);
  public Semaphore semaforoFr2_S3 = new Semaphore(1);
  public Semaphore semaforoFr3_S2 = new Semaphore(1);
  public Semaphore semaforoFr4_S1 = new Semaphore(1);
  public Semaphore semaforoFr1_P3 = new Semaphore(1);
  public Semaphore semaforoFr2_P1 = new Semaphore(1);
  public Semaphore semaforoFr1_V1 = new Semaphore(1);
  public Semaphore semaforoFr2_V2 = new Semaphore(1);
  public Semaphore semaforoFr1_Sl1 = new Semaphore(1);
  public Semaphore semaforoFr2_Sl2 = new Semaphore(1);
  public Semaphore semaforoFr2_Vr1 = new Semaphore(1);
  public Semaphore semaforoFr1_Vr2 = new Semaphore(1);
  public Semaphore semaforoFr4_Vr3 = new Semaphore(1);
  public Semaphore semaforoFr3_Vr4 = new Semaphore(1);

  public Semaphore semaforoFr1_D2 = new Semaphore(1);
  public Semaphore semaforoFr2_D1 = new Semaphore(1);

  public Semaphore semaforoV_S = new Semaphore(1);
  public Semaphore semaforoV_P = new Semaphore(1);
  public Semaphore semaforoV_Sl = new Semaphore(1);
  public Semaphore semaforoV1_Vr1 = new Semaphore(1);
  public Semaphore semaforoV2_Vr2 = new Semaphore(1);
  public Semaphore semaforoV_D = new Semaphore(1);
  public Semaphore semaforoS1_P1 = new Semaphore(1);
  public Semaphore semaforoS2_P2 = new Semaphore(1);

  public Semaphore semaforoS_Sl = new Semaphore(1);
  public Semaphore semaforoS1_Sl1 = new Semaphore(1);
  public Semaphore semaforoP_Sl = new Semaphore(1);
  public Semaphore semaforoP1_V1 = new Semaphore(1);
  public Semaphore semaforoP2_V2 = new Semaphore(1);
  public Semaphore semaforoP1_D1 = new Semaphore(1);
  public Semaphore semaforoP2_D2 = new Semaphore(1);
  public Semaphore semaforoP1_Sl1 = new Semaphore(1);
  public Semaphore semaforoP2_Sl2 = new Semaphore(1);
  public Semaphore semaforoP3_Sl3 = new Semaphore(1);
  public Semaphore semaforoSl_D = new Semaphore(1);

  public Semaphore semaforoVr1_D4 = new Semaphore(1);
  public Semaphore semaforoVr2_D3 = new Semaphore(1);
  public Semaphore semaforoVr3_D2 = new Semaphore(1);
  public Semaphore semaforoVr4_D1 = new Semaphore(1);

  public Semaphore semaforoS4_D4 = new Semaphore(1);
  public Semaphore semaforoS3_D3 = new Semaphore(1);
  public Semaphore semaforoS2_D2 = new Semaphore(1);
  public Semaphore semaforoS1_D1 = new Semaphore(1);
  public Semaphore semaforoS3_Vr3 = new Semaphore(1);
  public Semaphore semaforoS2_Vr2 = new Semaphore(1);

  /*
   * ***************************************************************
   * Metodo: initialize
   * Funcao: Inicializa a tela
   * Parametros: URL location, ResourceBundle resources
   * Retorno: void
   */
  public void initialize(URL location, ResourceBundle resources) {

  }

  public void ReiniciarCarros() {
    dafne.setLayoutX(246);
    dafne.setLayoutY(501);
    fred.setLayoutX(613);
    fred.setLayoutY(22);
    palhaco.setLayoutX(432);
    palhaco.setLayoutY(546);
    salsicha.setLayoutX(373);
    salsicha.setLayoutY(298);
    scoob.setLayoutX(191);
    scoob.setLayoutY(237);
    fantasma.setLayoutX(618);
    fantasma.setLayoutY(523);
    dracula.setLayoutX(262);
    dracula.setLayoutY(67);
    velma.setLayoutX(438);
    velma.setLayoutY(17);

  }
  
  @FXML // id do checkbox
  public void music(ActionEvent event) {
    // Verifica se o checkbox está selecionado
    if (music.isSelected()) {
      // Toca a música usando a classe CaixaDeMusica
      CaixaDeMusica.play("musica.wav");
    } else {
      // Pausa a música usando a classe CaixaDeMusica
      CaixaDeMusica.pause();
    }
  }

  /*
   * ***************************************************************
   * Metodo: buttonPaused
   * Funcao: Pausa/retoma a música de fundo ao clicar no botão
   * Parametros:
   * mE: Evento de clique do mouse no botão
   * Retorno:
   * void
   */
  @FXML
  public void buttonPaused(MouseEvent mE) {
    // Verifica se o botão que disparou o evento é o botaomusic
    if (mE.getSource().equals(botaomusic)) {
      System.out.println("[pausei]");
      // Inverte o estado do checkbox music
      if (music.isSelected()) {
        music.setSelected(false);
      } else {
        music.setSelected(true);
      }

    }
  }

  /****************************************************************
   * Metodo: pausar
   * Funcao: Pausar a música quando o checkbox é desmarcado
   * Parametros: event - evento que ocorreu
   * Retorno: void
   ****************************************************************/
  @FXML // Anotação que indica que o método é um evento de OnAction no SceneBuilder
  public void pausar(ActionEvent event) {
    if (event.getSource().equals(music)) { // Verifica se o evento ocorreu no checkbox "music"
      CaixaDeMusica.pause(); // Pausa a música
    } // fim do if
  }
  // fim do método pausar
}
