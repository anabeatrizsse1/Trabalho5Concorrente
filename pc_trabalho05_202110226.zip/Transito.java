import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Transito extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 5;
  private double eixoX = 618;
  private double eixoY = 523;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Transito(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarValor(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverFantasma();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverFantasma() throws InterruptedException {
    // controle.semaforoF1_Fr6.acquire();// rc entre fantasma e fred
    controle.semaforoF1_P5.acquire();

    SubirEixoY(510);
    controle.semaforoF5_S2.acquire();
    controle.semaforoF8_Fr6.release();
    SubirEixoY(409);
    controle.semaforoF1_Vr3.acquire();
    SubirEixoY(292);
    controle.semaforoF1_V5.acquire();// primeiro ponto critico do fantasma com o ultimo da velma
    controle.semaforoF1_D4.acquire();
    SubirEixoY(181);
    controle.semaforoF1_Vr3.release();
    controle.semaforoF5_S2.release();
    controle.semaforoF2_Fr7.acquire();
    SubirEixoY(22);
    // controle.semaforoF3_Fr1.acquire();
    // controle.semaforoF2_V1.acquire();
    MoverEixoXEsq(589);
    controle.semaforoF1_V5.release();// saiu do ponto critico do fantasma com o ultimo da velma
    MoverEixoXEsq(438);
    controle.semaforoF2_Vr1.acquire();
    MoverEixoXEsq(385);
    DescerEixoY(74);
    controle.semaforoF2_Fr7.release();
    // controle.semaforoF2_V1.release();
    DescerEixoY(124);
    MoverEixoXEsq(342);
    controle.semaforoF1_P5.release();
    controle.semaforoF2_Vr1.release();
    controle.semaforoF3_Vr9.acquire();
    MoverEixoXEsq(272);
    SubirEixoY(74);
    controle.semaforoF1_D4.release();
    controle.semaforoF4_Fr2.acquire();
    controle.semaforoF4_V3.acquire();

    controle.semaforoF3_V2.acquire();
    SubirEixoY(14);
    MoverEixoXEsq(197);
    controle.semaforoF3_Vr9.release();
    MoverEixoXEsq(24);
    // controle.semaforoF4_Fr2.release();
    // controle.semaforoF5_Fr3.acquire();
    controle.semaforoF3_V2.release();
    // controle.semaforoF4_V3.acquire();
    DescerEixoY(181);
    controle.semaforoF2_D1.acquire();

    controle.semaforoF4_Vr6.acquire();
    controle.semaforoF1_Sl2.acquire();
    controle.semaforoF1_S5.acquire();
    DescerEixoY(295);
    controle.semaforoF4_V3.release();
    DescerEixoY(400);
    controle.semaforoF4_Vr6.release();
    DescerEixoY(517);
    controle.semaforoF1_S5.release();
    DescerEixoY(554);
    controle.semaforoF2_Sl3.acquire();
    // controle.semaforoF6_Fr4.acquire();
    MoverEixoXDir(78);
    controle.semaforoF1_Sl2.release();
    // controle.semaforoF5_Fr3.release();
    MoverEixoXDir(148);
    SubirEixoY(523);
    controle.semaforoF2_D1.release();

    controle.semaforoF2_Sl3.release();
    controle.semaforoF4_Fr2.release();
    controle.semaforoF2_S4.acquire();
    SubirEixoY(409);
    controle.semaforoF5_Vr5.acquire();
    controle.semaforoF3_D2.acquire();

    SubirEixoY(338);
    controle.semaforoF2_S4.release();
    MoverEixoXDir(210);
    controle.semaforoF3_D2.release();

    MoverEixoXDir(270);
    SubirEixoY(287);
    controle.semaforoF3_Sl1.acquire();
    controle.semaforoF5_V4.acquire();
    controle.semaforoF3_S1.acquire();
    controle.semaforoF5_Vr5.release();
    controle.semaforoF6_Vr7.acquire();
    SubirEixoY(224);
    MoverEixoXDir(327);
    controle.semaforoF4_P3.acquire();
    controle.semaforoF7_Fr5.acquire();
    controle.semaforoF6_Vr7.release();
    controle.semaforoF7_Vr2.acquire();

    MoverEixoXDir(387);
    DescerEixoY(292);
    controle.semaforoF7_Vr2.release();
    controle.semaforoF8_Vr4.acquire();
    controle.semaforoF5_V4.release();
    controle.semaforoF3_S1.release();
    DescerEixoY(338);
    MoverEixoXDir(449);
    controle.semaforoF3_Sl1.release();
    controle.semaforoF4_P3.release();
    MoverEixoXDir(498);
    DescerEixoY(395);
    controle.semaforoF4_S3.acquire();
    controle.semaforoF8_Vr4.release();
    DescerEixoY(500);
    controle.semaforoF7_Fr5.release();
    controle.semaforoF4_S3.release();
    DescerEixoY(501);
    controle.semaforoF1_P5.acquire();

    DescerEixoY(554);
    controle.semaforoF8_Fr6.acquire();
    MoverEixoXDir(627);
    controle.semaforoF1_P5.release();

  }

  // public void Mover;
  /*
   * ***************************************************************
   * Metodo: moveDireitaX
   * Funcao: move a personagem em sua vassoura para a direita
   * Parametros: int ondeVai
   * Retorno: void
   */
  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarValor(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }
}
