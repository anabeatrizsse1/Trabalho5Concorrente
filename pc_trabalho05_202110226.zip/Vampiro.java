import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Vampiro extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 10;
  private double eixoX = 261;
  private double eixoY = 67;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Vampiro(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarValor(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverVampiro();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverVampiro() throws InterruptedException {
    controle.semaforoFr2_Vr1.acquire();

    SubirEixoY(15);

    MoverEixoXDir(325);
    controle.semaforoF2_Vr1.acquire();
    controle.semaforoP1_V1.acquire();

    MoverEixoXDir(386);
    DescerEixoY(80);
    controle.semaforoFr2_Vr1.release();
    DescerEixoY(173);
    controle.semaforoP1_Sl1.acquire();

    controle.semaforoV2_Vr2.acquire();

    controle.semaforoF2_Vr1.release();
    controle.semaforoF7_Vr2.acquire();
    controle.semaforoFr4_S1.acquire();
    DescerEixoY(233);
    MoverEixoXDir(449);
    controle.semaforoVr1_D4.acquire();

    controle.semaforoP1_Sl1.release();

    controle.semaforoP1_V1.release();

    controle.semaforoF7_Vr2.release();
    MoverEixoXDir(555);
    controle.semaforoF1_Vr3.acquire();

    MoverEixoXDir(612);
    DescerEixoY(288);
    controle.semaforoVr1_D4.release();

    controle.semaforoV2_Vr2.release();

    controle.semaforoFr4_S1.release();

    DescerEixoY(331);
    MoverEixoXEsq(554);
    controle.semaforoVr2_D3.acquire();

    controle.semaforoF1_Vr3.release();
    controle.semaforoF8_Vr4.acquire();
    MoverEixoXEsq(450);
    controle.semaforoP2_V2.acquire();
    controle.semaforoP3_Sl3.acquire();

    MoverEixoXEsq(386);
    controle.semaforoS2_Vr2.acquire();

    DescerEixoY(414);
    controle.semaforoF8_Vr4.release();
    controle.semaforoFr4_Vr3.acquire();

    DescerEixoY(546);
    MoverEixoXEsq(331);
    controle.semaforoP2_V2.release();

    controle.semaforoFr4_Vr3.release();
    controle.semaforoFr3_Vr4.acquire();

    MoverEixoXEsq(261);
    controle.semaforoF5_Vr5.acquire();
    SubirEixoY(500);
    controle.semaforoS2_Vr2.release();
    controle.semaforoS3_Vr3.acquire();

    controle.semaforoP3_Sl3.release();
    SubirEixoY(400);
    controle.semaforoVr2_D3.release();

    SubirEixoY(331);
    controle.semaforoS3_Vr3.release();

    controle.semaforoFr3_Vr4.release();
    MoverEixoXEsq(212);
    controle.semaforoVr3_D2.acquire();

    MoverEixoXEsq(83);
    controle.semaforoP2_Sl2.acquire();

    controle.semaforoF5_Vr5.release();
    controle.semaforoF4_Vr6.acquire();

    MoverEixoXEsq(21);
    SubirEixoY(288);
    controle.semaforoV1_Vr1.acquire();

    SubirEixoY(224);
    MoverEixoXDir(83);
    controle.semaforoVr3_D2.release();
    controle.semaforoVr4_D1.acquire();

    controle.semaforoF4_Vr6.release();
    MoverEixoXDir(197);
    controle.semaforoF6_Vr7.acquire();

    MoverEixoXDir(268);

    SubirEixoY(173);
    controle.semaforoP2_Sl2.release();

    controle.semaforoV1_Vr1.release();

    controle.semaforoF6_Vr7.release();
    controle.semaforoVr4_D1.release();

  
  }


  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarValor(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }

}
