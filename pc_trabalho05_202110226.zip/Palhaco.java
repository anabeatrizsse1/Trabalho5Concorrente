import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;

public class Palhaco extends Thread {
  TelaController controle = new TelaController();

  private int velocidade = 1;
  private double eixoX = 432;
  private double eixoY = 546;
  private ImageView imagem;
  private final double inicio1;
  private final double inicio2;
  private boolean start = true;
  private Slider slider;

  public Palhaco(TelaController controle, ImageView imagem, Slider slider) {
    this.inicio1 = eixoX;
    this.inicio2 = eixoY;
    this.imagem = imagem;
    this.controle = controle;
    this.slider = slider;
    modificarValor(slider);
  }

  public void run() {
    while (start) {
      try {
        MoverPalhaco();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

    }
  }

  public void recomecoThread() {
    slider.setValue(1);
  }

  public void MoverPalhaco() throws InterruptedException {
    // SubirEixoY(413);
    controle.semaforoP2_V2.acquire();

    MoverEixoXEsq(369);
    controle.semaforoF4_P3.acquire();

    controle.semaforoP_Sl.acquire();
    SubirEixoY(275);
    controle.semaforoP2_V2.release();
    controle.semaforoP1_V1.acquire();

    SubirEixoY(178);
    controle.semaforoP_Sl.release();
    controle.semaforoP1_D1.acquire();

    controle.semaforoS2_P2.release();

    controle.semaforoF4_P3.release();
    controle.semaforoF1_P5.acquire();
    // controle.semaforoF4_P3.release();

    SubirEixoY(80);
    controle.semaforoFr1_P3.acquire();

    SubirEixoY(7);
    MoverEixoXDir(438);
    controle.semaforoP1_V1.release();

    MoverEixoXDir(599);
    DescerEixoY(180);
    controle.semaforoF1_Vr3.acquire();

    controle.semaforoF5_S2.acquire();

    DescerEixoY(288);
    controle.semaforoP1_D1.release();

    controle.semaforoV_P.release();

    controle.semaforoFr1_P3.release();
    DescerEixoY(400);
    controle.semaforoF1_Vr3.release();

    controle.semaforoFr2_P1.acquire();
    DescerEixoY(523);
    controle.semaforoF5_S2.release();

    DescerEixoY(556);
    MoverEixoXEsq(438);
    // controle.semaforoP_Sl.acquire();

    controle.semaforoF1_P5.release();
    MoverEixoXEsq(371);
    controle.semaforoP2_V2.acquire();

    SubirEixoY(523);
    controle.semaforoS1_P1.acquire();
    SubirEixoY(376);
    controle.semaforoFr2_P1.release();
    controle.semaforoS1_P1.release();

    // controle.semaforoP_Sl.acquire();

    // SubirEixoY(376);
    // controle.semaforoF4_P3.acquire();

    SubirEixoY(288);
    controle.semaforoS2_P2.acquire();

    controle.semaforoV_P.acquire();
    SubirEixoY(275);
    controle.semaforoP2_V2.release();

  }

  // public void Mover;
  /*
   * ***************************************************************
   * Metodo: moveDireitaX
   * Funcao: move a personagem em sua vassoura para a direita
   * Parametros: int ondeVai
   * Retorno: void
   */
  public void MoverEixoXEsq(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX--;

    }

  }

  public void MoverEixoXDir(double x) throws InterruptedException {
    while (eixoX != x) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutX(eixoX);
      });
      eixoX++;

    }

  }

  public void SubirEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY--;

    }

  }

  public void DescerEixoY(double y) throws InterruptedException {
    while (eixoY != y) {
      sleep(500 / (velocidade * 5));
      Platform.runLater(() -> {
        imagem.setLayoutY(eixoY);
      });
      eixoY++;

    }

  }

  public void modificarValor(Slider slider) {
    slider.valueProperty().addListener((observable, oldValue, newValue) -> {
      velocidade = newValue.intValue();
    });
  }

}
